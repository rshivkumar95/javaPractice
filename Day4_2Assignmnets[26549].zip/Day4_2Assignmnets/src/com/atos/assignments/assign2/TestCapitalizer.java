package com.atos.assignments.assign2;

import java.util.Scanner;

public class TestCapitalizer {

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		Capitalizer c = new Capitalizer();
		
	
		System.out.println(" Output String : "+c.Capitalize("this is java language"));
		
		
		
	}
		
	}

/*
  Output String : This Is Java Language
 */
	
	


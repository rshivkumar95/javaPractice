package com.atos.assignments.assign3;

public class TestSpaceRemover {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SpaceRemover sr=new SpaceRemover();
		
		System.out.println(sr.removeSpaces("Manipal Global    Education        Services"));

	}

}

package com.rest.service;

import java.util.ArrayList;
import java.util.List;

import com.rest.model.Profile;

public class ProfileService {
	
List<Profile> list=new ArrayList<Profile>();
	
	public ProfileService()
	{
		list.add(new Profile("rshivkumar","Shivkumar","Rathod"));
		list.add(new Profile("radkishivani","Shivani","Vahadne"));		
		
	}
	
	public List<Profile> getAllProfiles()
	{
	
		return list;
	}

}

package com.atos.assignments.day4_1_2;

public interface Rewardable {
	
	public double rewardCalc(double amount);

}

package com.atos.assignments.assign3;

public class InvalidDOBException extends Exception{

	public InvalidDOBException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidDOBException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
